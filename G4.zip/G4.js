const listG4 = document.querySelector('#Section1 .group4')
listG4.textContent = 'kiminoto'